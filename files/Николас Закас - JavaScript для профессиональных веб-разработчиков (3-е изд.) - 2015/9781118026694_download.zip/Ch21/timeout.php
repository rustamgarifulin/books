<?php
    header("Content-Type: text/plain");   
    sleep(2000);
?>